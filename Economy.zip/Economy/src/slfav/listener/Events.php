<?php

namespace slfav\listener;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerLoginEvent;
use slfav\Economy;

class Events implements Listener
{
  public function onJoin(PlayerLoginEvent $e):void
  {
    $p = $e->getPlayer();
    
    if(!Economy::getInstance()->getDataManager()->isRegistered($p))
    {
      Economy::getInstance()->getDataManager()->register($p);
    }
  }
}