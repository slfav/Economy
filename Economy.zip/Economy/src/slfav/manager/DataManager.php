<?php

namespace slfav\manager;

use pocketmine\utils\Config;
use pocketmine\player\Player;
use slfav\Economy;

class DataManager
{
  private $data;
  
  public function __construct()
  {
    $this->data = new Config(Economy::getInstance()->getDataFolder()."balance.json", Config::JSON);
  }
  
  public function isRegistered(Player $player):bool
  {
    if($this->data->exists($player->getName()))
    {
      return true;
    }
    return false;
  }
  
  public function register(Player $player)
  {
    $name = $player->getName();
    $balance = 1000;
    $this->data->set(
      $name,
      [
        "balance" => $balance
      ]
    );
    $this->data->save();
  }
  
  public function setBalance(Player $player, int $amount)
  {
    $name = $player->getName();
    $this->data->set(
      $name,
      [
        "balance" => $amount
      ]
    );
    $this->data->save();
  }
  
  public function getBalance(Player $player)
  {
    $name = $player->getName();
    $bal = $this->data->get($name)["balance"];
    return $bal;
  }
  
  public function addBalance(Player $player, int $amount)
  {
    $this->setBalance($player, $this->getBalance($player)+$amount);
  }
  
  public function removeBalance(Player $player, int $amount)
  {
    $this->setBalance($player, $this->getBalance($player)-$amount);
  }
}