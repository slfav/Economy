<?php

namespace slfav\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;
use slfav\Economy;

class PayBalanceCommand extends Command
{
  public function __construct()
  {
    parent::__construct("pay", "Pay someone and give money");
    $this->setPermission("balance.pay");
  }
  
  public function execute(CommandSender $sender, string $label, array $args)
  {
    if(!isset($args[0]))
    {
      $sender->sendMessage("§cYou forgot argument 0: Player. Usage: /pay [player] [amount]");
      return;
    }
    
    if(!isset($args[1]))
    {
      $sender->sendMessage("§cYou forgot argument 1: Amount of Money. Usage: /pay [player] [amount]");
      return;
    }
    
    if(!is_numeric($args[1]))
    {
      $sender->sendMessage("§cArgument 1 (Amount of Money) must be an integer (Numeric)");
      return;
    }
    
    $p = $sender->getServer()->getPlayerByPrefix($args[0]);
    $a = $args[1];
    $bal = Economy::getInstance()->getDataManager()->getBalance($sender);
    
    if($a > $bal)
    {
      $sender->sendMessage("§cYou don't have enough money");
      return;
    }
    
    if($p === null)
    {
      $sender->sendMessage("§cThe player doesn't exist");
      return;
    }
    
    if(!$p instanceof Player)
    {
      $sender->sendMessage("§cThe target isn't a player");
    }
    
    Economy::getInstance()->getDataManager()->addBalance($p, $a);
    Economy::getInstance()->getDataManager()->removeBalance($sender, $a);
  }
}