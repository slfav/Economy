<?php

namespace slfav\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;
use slfav\Economy;

class AddBalanceCommand extends Command
{
  public function __construct()
  {
    parent::__construct("balanceadd", "Add money to another player's balance");
    $this->setPermission("balance.add");
  }
  
  public function execute(CommandSender $sender, string $label, array $args)
  {
    if(!isset($args[0]))
    {
      $sender->sendMessage("§cYou forgot argument 0: Player. Usage: /balanceadd [player] [amount]");
      return;
    }
    
    if(!isset($args[1]))
    {
      $sender->sendMessage("§cYou forgot argument 1: Amount of Money. Usage: /balanceadd [player] [amount]");
      return;
    }
    
    if(!is_numeric($args[1]))
    {
      $sender->sendMessage("§cArgument 1 (Amount of Money) must be an integer (Numeric)");
      return;
    }
    
    $p = $sender->getServer()->getPlayerByPrefix($args[0]);
    $a = $args[1];
    
    if($p === null)
    {
      $sender->sendMessage("§cThe player doesn't exist");
      return;
    }
    
    if(!$p instanceof Player)
    {
      $sender->sendMessage("§cThe target isn't a player");
    }
    
    Economy::getInstance()->getDataManager()->addBalance($p, $a);
  }
}