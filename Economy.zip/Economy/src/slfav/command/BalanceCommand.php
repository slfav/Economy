<?php

namespace slfav\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use slfav\Economy;

class BalanceCommand extends Command
{
  public function __construct()
  {
    parent::__construct("balance", "See your total balance");
    $this->setPermission("balance.cmd");
  }
  
  public function execute(CommandSender $sender, string $label, array $argd)
  {
    if(!$sender instanceof Player)return;
    
    $bal = Economy::getInstance()->getDataManager()->getBalance($sender);
    $sender->sendMessage("§aBalance: §7$".$bal);
  }
}