<?php

namespace slfav;

use pocketmine\utils\SingletonTrait;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use slfav\manager\DataManager;
use slfav\listener\Events;
use slfav\command\AddBalanceCommand;
use slfav\command\BalanceCommand;
use slfav\command\RemoveBalanceCommand;
use slfav\command\SetBalanceCommand;
use slfav\command\PayBalanceCommand;

class Economy extends PluginBase
{
  use SingletonTrait;
  
  private DataManager $dataManager;
  
  public function onLoad():void
  {
    self::setInstance($this);
  }
  
  public function onEnable():void
  {
    $this->getServer()->getPluginManager()->registerEvents(new Events(), $this);
    $this->getServer()->getCommandMap()->register("balanceadd", new AddBalanceCommand());
    $this->getServer()->getCommandMap()->register("balance", new BalanceCommand());
    $this->getServer()->getCommandMap()->register("balanceremove", new RemoveBalanceCommand());
    $this->getServer()->getCommandMap()->register("balanceset", new SetBalanceCommand());
    $this->getServer()->getCommandMap()->register("pay", new PayBalanceCommand());
  }
  
  public function getDataManager():DataManager
  {
    return new DataManager;
  }
}